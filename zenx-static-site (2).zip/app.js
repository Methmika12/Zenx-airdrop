// ZENX - Crypto Testnet Rewards Platform
// Static Version with LocalStorage Demo

// App State
const state = {
    user: JSON.parse(localStorage.getItem('zenx_user')) || null,
    wallet: JSON.parse(localStorage.getItem('zenx_wallet')) || null,
    tasks: JSON.parse(localStorage.getItem('zenx_tasks')) || getDefaultTasks(),
    referrals: JSON.parse(localStorage.getItem('zenx_referrals')) || [],
    leaderboard: JSON.parse(localStorage.getItem('zenx_leaderboard')) || getDefaultLeaderboard()
};

function getDefaultTasks() {
    return [
        {
            id: 1,
            title: 'Follow on X (Twitter)',
            description: 'Follow @Methmika12 on X to earn rewards',
            type: 'social',
            points: 50,
            link: 'https://x.com/Methmika12',
            icon: 'twitter',
            completed: false
        },
        {
            id: 2,
            title: 'Join Telegram Channel',
            description: 'Join ZENX Testnet Telegram channel',
            type: 'social',
            points: 50,
            link: 'https://t.me/zenx_testnet',
            icon: 'telegram',
            completed: false
        },
        {
            id: 3,
            title: 'Join Telegram Group',
            description: 'Join ZENX Community Telegram group',
            type: 'community',
            points: 50,
            link: 'https://t.me/zenx_community',
            icon: 'telegram',
            completed: false
        }
    ];
}

function getDefaultLeaderboard() {
    return [
        { rank: 1, username: 'CryptoKing', balance: 12500, referrals: 45, tasks: 12, avatar: 'C' },
        { rank: 2, username: 'ZenMaster', balance: 11200, referrals: 38, tasks: 10, avatar: 'Z' },
        { rank: 3, username: 'Web3Warrior', balance: 9800, referrals: 32, tasks: 11, avatar: 'W' },
        { rank: 4, username: 'TokenHunter', balance: 8500, referrals: 28, tasks: 9, avatar: 'T' },
        { rank: 5, username: 'DeFiDreamer', balance: 7200, referrals: 24, tasks: 8, avatar: 'D' },
        { rank: 6, username: 'NFTCollector', balance: 6500, referrals: 20, tasks: 7, avatar: 'N' },
        { rank: 7, username: 'ChainChaser', balance: 5800, referrals: 18, tasks: 7, avatar: 'C' },
        { rank: 8, username: 'BlockBuilder', balance: 4900, referrals: 15, tasks: 6, avatar: 'B' },
        { rank: 9, username: 'SatoshiFan', balance: 4200, referrals: 12, tasks: 5, avatar: 'S' },
        { rank: 10, username: 'EtherWhale', balance: 3500, referrals: 10, tasks: 5, avatar: 'E' }
    ];
}

// Utility Functions
function generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = 'ZENX';
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = 'toast show ' + type;
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

// Modal Functions
function showModal(type) {
    document.getElementById(type + 'Modal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(type) {
    document.getElementById(type + 'Modal').classList.remove('active');
    document.body.style.overflow = '';
}

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
});

// Mobile Menu
function toggleMenu() {
    document.getElementById('mobileMenu').classList.toggle('active');
}

// Auth Functions
function handleLogin(e) {
    e.preventDefault();
    const email = e.target.querySelector('input[type="email"]').value;
    const password = e.target.querySelector('input[type="password"]').value;

    // Demo login - in real app, this would call Supabase
    const user = {
        id: 'user_' + Date.now(),
        email: email,
        username: email.split('@')[0],
        balance: 0,
        referralCode: generateReferralCode(),
        createdAt: new Date().toISOString()
    };

    state.user = user;
    localStorage.setItem('zenx_user', JSON.stringify(user));

    closeModal('login');
    showToast('Welcome back!');
    updateUI();
}

function handleRegister(e) {
    e.preventDefault();
    const username = e.target.querySelector('input[type="text"]').value;
    const email = e.target.querySelector('input[type="email"]').value;
    const password = e.target.querySelector('input[type="password"]').value;

    // Demo register
    const user = {
        id: 'user_' + Date.now(),
        email: email,
        username: username,
        balance: 0,
        referralCode: generateReferralCode(),
        createdAt: new Date().toISOString()
    };

    state.user = user;
    localStorage.setItem('zenx_user', JSON.stringify(user));

    closeModal('register');
    showToast('Account created successfully!');
    updateUI();
}

function logout() {
    state.user = null;
    state.wallet = null;
    localStorage.removeItem('zenx_user');
    localStorage.removeItem('zenx_wallet');
    showToast('Logged out successfully');
    updateUI();
}

// Wallet Functions
async function connectWallet() {
    if (typeof window.ethereum !== 'undefined') {
        try {
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            const address = accounts[0];

            state.wallet = { address };
            localStorage.setItem('zenx_wallet', JSON.stringify(state.wallet));

            showToast('Wallet connected: ' + address.slice(0, 6) + '...' + address.slice(-4));
            updateUI();
        } catch (error) {
            showToast('Failed to connect wallet', 'error');
        }
    } else {
        showToast('Please install MetaMask', 'error');
    }
}

// Task Functions
function completeTask(taskId) {
    if (!state.user) {
        showModal('login');
        return;
    }

    const task = state.tasks.find(t => t.id === taskId);
    if (!task || task.completed) return;

    // Open task link
    if (task.link) {
        window.open(task.link, '_blank');
    }

    // Mark as completed after 2 seconds
    setTimeout(() => {
        task.completed = true;
        state.user.balance += task.points;

        localStorage.setItem('zenx_tasks', JSON.stringify(state.tasks));
        localStorage.setItem('zenx_user', JSON.stringify(state.user));

        showToast('+' + task.points + ' ZENX earned!');
        updateUI();
    }, 2000);
}

// Referral Functions
function copyRefLink() {
    if (!state.user) {
        showModal('login');
        return;
    }

    const link = 'https://zenx.app/register?ref=' + state.user.referralCode;
    navigator.clipboard.writeText(link).then(() => {
        showToast('Referral link copied!');
    });
}

function shareTwitter() {
    if (!state.user) {
        showModal('login');
        return;
    }

    const text = 'Join ZENX and earn crypto rewards! Use my referral link: https://zenx.app/register?ref=' + state.user.referralCode;
    window.open('https://twitter.com/intent/tweet?text=' + encodeURIComponent(text), '_blank');
}

function shareTelegram() {
    if (!state.user) {
        showModal('login');
        return;
    }

    const text = 'Join ZENX and earn crypto rewards!';
    const url = 'https://zenx.app/register?ref=' + state.user.referralCode;
    window.open('https://t.me/share/url?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(text), '_blank');
}

// UI Update Functions
function updateUI() {
    updateNav();
    updateDashboard();
    updateTasks();
    updateReferral();
    updateProfile();
}

function updateNav() {
    const navActions = document.querySelector('.nav-actions');
    if (state.user) {
        navActions.innerHTML = `
            <span class="balance-badge">${state.user.balance.toLocaleString()} ZENX</span>
            <button class="btn btn-secondary btn-sm" onclick="logout()">Logout</button>
        `;
    } else {
        navActions.innerHTML = `
            <button class="btn btn-primary" onclick="showModal('login')">Sign In</button>
        `;
    }
}

function updateDashboard() {
    if (!state.user) {
        document.getElementById('dashBalance').textContent = '0';
        document.getElementById('dashTasks').textContent = '0';
        document.getElementById('dashReferrals').textContent = '0';
        document.getElementById('dashProgress').textContent = '0%';
        return;
    }

    const completedTasks = state.tasks.filter(t => t.completed).length;
    const progress = Math.round((completedTasks / state.tasks.length) * 100);

    document.getElementById('dashBalance').textContent = state.user.balance.toLocaleString();
    document.getElementById('dashTasks').textContent = completedTasks;
    document.getElementById('dashReferrals').textContent = state.referrals.length;
    document.getElementById('dashProgress').textContent = progress + '%';

    // Update wallet status
    const walletStatus = document.getElementById('walletStatus');
    if (state.wallet) {
        walletStatus.innerHTML = `
            <div class="wallet-connected">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 32px; height: 32px; background: rgba(34, 197, 94, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--success);">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12V7H5a2 2 0 01-2-2V5a2 2 0 012-2h14v4"/>
                            <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V7"/>
                            <path d="M16 12h.01"/>
                        </svg>
                    </div>
                    <div>
                        <div style="font-family: monospace; font-size: 0.875rem; color: var(--text-primary);">${state.wallet.address.slice(0, 6)}...${state.wallet.address.slice(-4)}</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">MetaMask Connected</div>
                    </div>
                </div>
                <span class="badge badge-success">Active</span>
            </div>
            <button class="btn btn-outline w-full" onclick="window.open('https://etherscan.io/address/${state.wallet.address}', '_blank')">View on Explorer</button>
        `;
    }
}

function updateTasks() {
    const tasksList = document.getElementById('tasksList');
    const completedCount = state.tasks.filter(t => t.completed).length;

    document.getElementById('taskCompleted').textContent = completedCount + '/' + state.tasks.length + ' Completed';

    tasksList.innerHTML = state.tasks.map(task => {
        const isCompleted = task.completed;
        const iconSvg = task.icon === 'twitter' 
            ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'
            : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>';

        return `
            <div class="task-card ${isCompleted ? 'completed' : ''}">
                <div class="task-icon ${isCompleted ? 'green' : 'purple'}">
                    ${isCompleted 
                        ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>'
                        : iconSvg
                    }
                </div>
                <div class="task-content">
                    <div class="task-header">
                        <h3 class="task-title">${task.title}</h3>
                        <span class="badge badge-primary">+${task.points} ZENX</span>
                    </div>
                    <p class="task-desc">${task.description}</p>
                    <div class="task-actions">
                        ${isCompleted 
                            ? `<div class="task-completed">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
                                <span>Completed</span>
                            </div>`
                            : `<button class="btn btn-primary btn-sm" onclick="completeTask(${task.id})">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 6px;">
                                    <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
                                    <polyline points="15 3 21 3 21 9"/>
                                    <line x1="10" y1="14" x2="21" y2="3"/>
                                </svg>
                                Complete Task
                            </button>
                            ${task.link ? `<a href="${task.link}" target="_blank" class="btn btn-outline btn-sm">Preview</a>` : ''}`
                        }
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function updateReferral() {
    if (!state.user) {
        document.getElementById('refCount').textContent = '0';
        document.getElementById('refEarned').textContent = '0';
        document.getElementById('refLink').textContent = 'https://zenx.app/register?ref=ZENX000000';
        return;
    }

    const earned = state.referrals.length * 100;
    document.getElementById('refCount').textContent = state.referrals.length;
    document.getElementById('refEarned').textContent = earned;
    document.getElementById('refLink').textContent = 'https://zenx.app/register?ref=' + state.user.referralCode;
}

function updateLeaderboard() {
    const tbody = document.getElementById('leaderboardBody');

    // Add current user if logged in
    let displayData = [...state.leaderboard];
    if (state.user) {
        const userEntry = displayData.find(e => e.username === state.user.username);
        if (!userEntry) {
            const completedTasks = state.tasks.filter(t => t.completed).length;
            displayData.push({
                rank: '-',
                username: state.user.username,
                balance: state.user.balance,
                referrals: state.referrals.length,
                tasks: completedTasks,
                avatar: state.user.username.charAt(0).toUpperCase(),
                isCurrentUser: true
            });
        }
    }

    tbody.innerHTML = displayData.map((entry, index) => {
        const rankClass = entry.rank === 1 ? 'rank-1' : entry.rank === 2 ? 'rank-2' : entry.rank === 3 ? 'rank-3' : '';
        const rankIcon = entry.rank === 1 ? '👑' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : '#' + entry.rank;

        return `
            <tr style="${entry.isCurrentUser ? 'background: rgba(139, 92, 246, 0.05);' : ''}">
                <td>
                    <div class="rank-cell">
                        <span class="${rankClass}" style="font-size: 1.25rem;">${rankIcon}</span>
                    </div>
                </td>
                <td>
                    <div class="user-cell">
                        <div class="user-avatar">${entry.avatar}</div>
                        <span class="user-name">${entry.username} ${entry.isCurrentUser ? '(You)' : ''}</span>
                    </div>
                </td>
                <td>
                    <div class="balance-cell">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                        ${entry.balance.toLocaleString()}
                    </div>
                </td>
                <td style="color: var(--text-secondary);">${entry.referrals}</td>
                <td style="color: var(--text-secondary);">${entry.tasks}</td>
            </tr>
        `;
    }).join('');
}

function updateProfile() {
    if (!state.user) {
        document.getElementById('profileAvatar').textContent = 'U';
        document.getElementById('profileName').textContent = 'User';
        document.getElementById('profileEmail').textContent = 'user@example.com';
        document.getElementById('profileBalance').textContent = '0 ZENX';
        document.getElementById('profBalance').textContent = '0';
        document.getElementById('profTasks').textContent = '0';
        document.getElementById('profRefs').textContent = '0';
        return;
    }

    const completedTasks = state.tasks.filter(t => t.completed).length;

    document.getElementById('profileAvatar').textContent = state.user.username.charAt(0).toUpperCase();
    document.getElementById('profileName').textContent = state.user.username;
    document.getElementById('profileEmail').textContent = state.user.email;
    document.getElementById('profileBalance').textContent = state.user.balance.toLocaleString() + ' ZENX';
    document.getElementById('profBalance').textContent = state.user.balance.toLocaleString();
    document.getElementById('profTasks').textContent = completedTasks;
    document.getElementById('profRefs').textContent = state.referrals.length;
}

// Animated Counter
function animateCounters() {
    const counters = document.querySelectorAll('.stat-value[data-target]');

    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const start = 0;
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.floor(easeOut * target);

            counter.textContent = formatNumber(current);

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }

        requestAnimationFrame(update);
    });
}

// Smooth Scroll
function scrollToSection(id) {
    document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Observe sections for animation
    document.querySelectorAll('.section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(section);
    });

    // Animate stats on load
    setTimeout(animateCounters, 500);

    // Update all UI
    updateUI();
    updateLeaderboard();

    // Listen for MetaMask account changes
    if (window.ethereum) {
        window.ethereum.on('accountsChanged', (accounts) => {
            if (accounts.length === 0) {
                state.wallet = null;
                localStorage.removeItem('zenx_wallet');
                updateUI();
            } else {
                state.wallet = { address: accounts[0] };
                localStorage.setItem('zenx_wallet', JSON.stringify(state.wallet));
                updateUI();
            }
        });
    }
});

// Check for referral code in URL
const urlParams = new URLSearchParams(window.location.search);
const refCode = urlParams.get('ref');
if (refCode) {
    localStorage.setItem('zenx_referral', refCode);
}
